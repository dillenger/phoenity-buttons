var phoenityButtonsID = browser.runtime.getURL("");
console.log(phoenityButtonsID);

browser.phoenityButtonsApi.phoenityButtons();
